const fruits = ['banana', 'apple', 'peach', 'cherry'];

console.log(fruits); // Outputs array
console.log(...fruits); // Outputs each string in array individually